

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-breadcrumb">
    <div class="row">
        <div class="col-6">
            <h4 class="page-title">Dashboard</h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/admin">Home</a></li>
                    <li class="breadcrumb-item" aria-current="page">Orders</li>
                </ol>
            </nav>
        </div>
    </div>
</div>

<div class="container-fluid">

    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-md-flex align-items-center">
                        <div>
                            <h4 class="card-title">Orders</h4>
                            <!-- <p class="card-subtitle">Overview of Top Selling Items</p> -->
                        </div>
                        <div class="ml-auto">
                            <div class="dl">
                                <a class="btn btn-primary" target="__blank" href="<?php echo e(route('generate_order_pdf')); ?>">Generate pdf</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table v-middle">
                        <thead>
                            <tr class="bg-light">
                                <th class="border-top-0">Products</th>
                                <th class="border-top-0">User_Name</th>
                                <th class="border-top-0">Quantity</th>
                                <th class="border-top-0">Cancel_order</th>
                                <th class="border-top-0">Created_at</th>
                                <th class="border-top-0">Total</th>
                                <!-- <th class="border-top-0">Earnings</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php
                                    $product = DB::table('products')->where('id', $order->product_id)->first();
                                    ?>
                                    <div class="d-flex align-items-center">
                                        <div class="m-r-10">
                                            <a href="<?php echo e(route('singleproducts',['id' => $order->product_id])); ?>" class="text-white">
                                                <img src="<?php echo e(asset('products_image/'.$product->image)); ?>" class="rounded-circle" style="width: 40px; height: 40px; object-fit: cover;">
                                            </a>
                                        </div>&nbsp;&nbsp;&nbsp;
                                        <div class="">
                                            <a href="<?php echo e(route('single_order', ['id' => $order->id])); ?>" class="m-b-0 font-16" style="color: blue;"><?php echo e($product->name); ?></a>
                                        </div>
                                    </div>
                                </td>
                                <?php
                                $user = DB::table('users')->where('id', $order->user_id)->first();
                                ?>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($order->quantity); ?></</td>
                                <td>
                                    <?php if($order->cancel == 0): ?>
                                    <label class="label label-danger btn btn-success">Ongoing</</label>
                                    <?php else: ?>
                                    <label class="label label-success btn btn-danger">Cancel</</label>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($order->created_at->format('M d, Y')); ?></</td>
                                <td>$<?php echo e($product->price*$order->quantity); ?>.00</td>
                                <!-- <td>
                                    <h5 class="m-b-0">$2850.06</h5>
                                </td> -->
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <nav aria-label="Pagination">
                <ul class="pagination justify-content-center">
                    <?php if($paginator->onFirstPage()): ?>
                        <li class="page-item disabled">
                            <span class="page-link"><?php echo e(__('Previous')); ?></span>
                        </li>
                    <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><?php echo e(__('Previous')); ?></a>
                        </li>
                    <?php endif; ?>

                    <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
                        <?php if($i == $paginator->currentPage()): ?>
                            <li class="page-item active"><span class="page-link"><?php echo e($i); ?></span></li>
                        <?php else: ?>
                            <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a></li>
                        <?php endif; ?>
                    <?php endfor; ?>

                    <?php if($paginator->hasMorePages()): ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><?php echo e(__('Next')); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled">
                            <span class="page-link"><?php echo e(__('Next')); ?></span>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admindefault', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/admin/orders.blade.php ENDPATH**/ ?>