

<?php $__env->startSection('title', 'Quotations || Admin'); ?>

<?php $__env->startSection('content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-4">
                <h2>Quotations</h2>
                <?php if($quotations->isEmpty()): ?>
                    <div class="alert alert-warning">
                        No quotations found.
                    </div>
                <?php else: ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User Name</th>
                                <th>Name</th>
                                <th>No of items</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $id = 0;
                            ?>
                            <?php $__currentLoopData = $quotations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $id++; ?>
                                <tr>
                                    <td><?php echo e($id); ?></td>
                                    <?php
                                    $name = DB::table('users')->where('id', $quotation->user_id)->first();
                                    ?>
                                    <td>
                                        <?php echo e($name->name); ?>

                                        <input type="hidden" class="user_id" value="<?php echo e($quotation->user_id); ?>">
                                    </td>
                                    <td>
                                        <span class="quotation-name"><?php echo e($quotation->name); ?></span>
                                    </td>
                                    <?php
                                    $no_of_items = DB::table('quotation_products')->where('quotation_id', $quotation->id)->count();
                                    ?>
                                    <td><?php echo e($no_of_items); ?></td>
                                    <td><?php echo e($quotation->created_at ? $quotation->created_at->format('d M Y') : 'N/A'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('showquotationproducts' ,['id' => $quotation->id])); ?>" class="btn btn-info view-btn" data-id="<?php echo e($quotation->id); ?>">View</a>
                                        <button class="btn btn-warning edit-btn" data-id="<?php echo e($quotation->id); ?>">Edit</button>
                                        <button class="btn btn-success save-btn" data-id="<?php echo e($quotation->id); ?>" style="display:none;">Save</button>
                                        <form action="<?php echo e(route('deletequotation', ['id' => $quotation->id])); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="button" class="btn btn-danger delete-btn">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <div id="loader-container" class="loader-container" style="display: none;">
            <div id="loader" class="loader"></div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.edit-btn').on('click', function() {
                var row = $(this).closest('tr');
                var quotationName = row.find('.quotation-name');
                var quotationId = $(this).data('id');

                var name = quotationName.text();
                quotationName.html('<input type="text" class="form-control edit-input" value="' + name + '">');

                row.find('.view-btn, .edit-btn, .delete-btn').hide();
                row.find('.save-btn').show();
            });

            $('.save-btn').on('click', function() {
                var row = $(this).closest('tr');
                var inputField = row.find('.edit-input');
                var newName = inputField.val();
                var quotationId = $(this).data('id');
                var userid = row.find('.user_id').val();
                $('#loader-container').show();

                $.ajax({
                    url: '<?php echo e(route('updatequotationname')); ?>', 
                    type: 'POST',
                    data: {
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        id: quotationId,
                        name: newName,
                        userid: userid
                    },
                    success: function(response) {
                        row.find('.quotation-name').text(newName);
                        row.find('.view-btn, .edit-btn, .delete-btn').show();
                        row.find('.save-btn').hide();
                        $('#loader-container').hide();
                    },
                    error: function(xhr) {
                        alert('A quotation with this name already exists for the current user.');
                        $('#loader-container').hide();
                    }
                });
            });

            $('.delete-btn').on('click', function(e) {
                e.preventDefault();

                var form = $(this).closest('form');
                
                if (confirm("Please confirm if you wish to delete the quotation. Once deleted, it cannot be retrieved along with the associated products.")) {
                    form.submit(); 
                }
            });
        });

    </script>
    <style>
         /* Loader styles */
         .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.7);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .loader {
            border: 8px solid #f3f3f3; /* Light grey */
            border-top: 8px solid #3498db; /* Blue */
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admindefault', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/admin/quotations.blade.php ENDPATH**/ ?>