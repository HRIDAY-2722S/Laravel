<!-- order-pdf.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Order || PDF</title>
</head>
<body><?php $sr = 0; ?>
    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $sr++; ?>
        <h2 <?php if($order->cancel == 1): ?> style="color: red;" <?php endif; ?>>Order Items(<?php echo e($sr); ?>)</h2>
        <table>
            <thead>
                <tr>
                    <th>Product</th>
                    <th>User Name</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Subtotal</th>
                    <th>Status</th>
                    <th>Created_at</th>
                </tr>
            </thead>
            <tbody>
                    <tr style="<?php if($order->cancel ==1 ): ?> color: red; <?php endif; ?>">
                        <?php
                        $product = DB::table('products')->where('id', $order->product_id)->first();
                        ?>
                        <td><?php echo e($product->name); ?></td>
                        <?php
                        $user = DB::table('users')->where('id', $order->user_id)->first();
                        ?>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($order->quantity); ?></td>
                        <td>$<?php echo e($product->price); ?></td>
                        <td>$<?php echo e($product->price*$order->quantity); ?>.00</td>
                        <td>
                            <?php if($order->cancel == 0): ?>
                            <span class="badge badge-success">Active</span>
                            <?php else: ?>
                            <span class="badge badge-danger">Cancelled</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($order->created_at->format('d M, Y')); ?></td>
                    </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="6">Total</th>
                    <th>$<?php echo e($product->price*$order->quantity); ?>.00</th>
                </tr>
            </tfoot>
        </table>

        <h2>Payment Information</h2>
        <p>Payment Method: Credit Card</p>
        <p>Payment Date: <?php echo e($order->created_at->format('d M, Y h:i:s A')); ?></p>

        <h2>Shipping Information</h2>
        <?php
        $address = DB::table('addresses')->where('id', $order->address_id)->first();
        ?>
        <!-- <p>Shipping Method: <?php echo e($order->shipping_method); ?></p> -->
        <p>Shipping Address: <?php echo e($address->name); ?>, <?php echo e($address->address_lane_1); ?>, <?php echo e($address->area); ?>,<?php echo e($address->landmark); ?>, <?php echo e($address->town); ?>, <?php echo e($address->state); ?>, <?php echo e($address->country); ?>, <?php echo e($address->pincode); ?>, (<?php echo e($address->mobile); ?>)</p>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
    </style>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/pdf/order.blade.php ENDPATH**/ ?>