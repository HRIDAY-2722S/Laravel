<footer>
    <p>&copy; All Rights Reserved. <br />Designed and Developed by <a href=""></a>.</p>
</footer><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/layouts/adminfooter.blade.php ENDPATH**/ ?>