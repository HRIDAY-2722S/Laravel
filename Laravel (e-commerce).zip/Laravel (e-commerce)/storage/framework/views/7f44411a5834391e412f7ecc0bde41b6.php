

<?php $__env->startSection('title', 'Admin || Orderdetails'); ?>

<?php $__env->startSection('content'); ?>

  <?php if(session('success')): ?>
    <div class="m-4 alert alert-success" style="padding: 15px;">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <div class="card m-4" style="width: 96%">
    <div class="card-body">
      <div class="row">
        <div class="col-md-6 p-3 border border-secondary rounded">
          <h5 class="card-title">User Information</h5>
          <?php
          $user = DB::table('users')->where('id', $order->user_id)->first();
          ?>
          <?php if($order->user_id == "0"): ?>
            <div class="form-group row">
              <div class="col-md-8">
                <label for="name">Order made by the guest in guest mode.</label>
                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name" value="<?php echo e($user->name); ?>" readonly>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
          <?php else: ?>
          <form method="post" action="<?php echo e(route('save_user', ['id' => $order->id])); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
              <div class="col-md-6">
                <label for="name">Name:</label>
                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name" value="<?php echo e($user->name); ?>" placeholder="Enter name">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-md-6">
                <label for="status">Status:</label>
                <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status">
                  <option value="">Select option</option>
                  <option value="1" <?php echo e($user->status == '1' ? 'selected' : ''); ?>>Active</option>
                  <option value="0" <?php echo e($user->status == '0' ? 'selected' : ''); ?>>Inactive</option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
            </div>
            <div class="form-group row">
              <div class="col-md-9">
                <label for="email">Email:</label>
                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" value="<?php echo e($user->email); ?>" placeholder="Enter email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-md-3">
                <label for="submit"> &nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">Update</button>
              </div>
            </div>
          </form>
          <?php endif; ?>
        </div>
        <div class="col-md-3 p-3 border border-secondary rounded">
          <h5 class="card-title">
            Shipping Address
            <a href="<?php echo e(route("edit_user_address", ['id' => $order->id])); ?>"><i class="fas fa-pencil-alt float-right" style="cursor: pointer;"></i></a>
          </h5>
          <?php
          $shipping = DB::table('addresses')->where('id', $order->address_id)->first();
          ?>
          <p class="card-text"><?php echo e($shipping->address_lane_1); ?>, <?php echo e($shipping->area); ?>, <?php echo e($shipping->landmark); ?></p>
          <p class="card-text"><?php echo e($shipping->town); ?>, <?php echo e($shipping->state); ?>, <?php echo e($shipping->pincode); ?></p>
          <p class="card-text"><?php echo e($shipping->name); ?> (<?php echo e($shipping->mobile); ?>)</p>
          <p class="card-text"><?php echo e($shipping->email); ?></p>
        </div>
        <div class="col-md-3 p-3 border border-secondary rounded">
          <h5 class="card-title">
            Billing Address
            <a href="<?php echo e(route("edit_user_address", ['id' => $order->address_id])); ?>"><i class="fas fa-pencil-alt float-right" style="cursor: pointer;"></i></a>
          </h5>
          <p class="card-text"><?php echo e($shipping->address_lane_1); ?>, <?php echo e($shipping->area); ?>, <?php echo e($shipping->landmark); ?></p>
          <p class="card-text"><?php echo e($shipping->town); ?>, <?php echo e($shipping->state); ?>, <?php echo e($shipping->pincode); ?></p>
          <p class="card-text"><?php echo e($shipping->name); ?> (<?php echo e($shipping->mobile); ?>)</p>
          <p class="card-text"><?php echo e($shipping->email); ?></p>
        </div>
      </div>
    </div>
  </div>

  <div class="card m-4" style="width: 96%">
    <div class="card-body">
      <h5 class="card-title">Product Details</h5>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Product Image</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $product = DB::table('products')->where('id', $order->product_id)->first();
          ?>
          <tr>
            <td><img src="<?php echo e(asset('products_image/' . $product->image)); ?>" alt="Product Image" height="50" width="50"></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($order->quantity); ?></td>
            <td>$<?php echo e($product->price); ?></td>
            <td>$<?php echo e($product->price*$order->quantity); ?>.00</td>
          </tr>
          <tr>
            <th colspan="4">Subtotal</th>
            <td>$<?php echo e($product->price*$order->quantity); ?>.00</td>
          </tr>
          <tr>
            <th colspan="4">Tax (0%)</th>
            <td>$0.00</td>
          </tr>
          <tr>
            <th colspan="4">Total</th>
            <td>$<?php echo e($product->price*$order->quantity); ?>.00</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card m-4" style="width: 96%">
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <h5 class="card-title">Payment Details</h5>
          <div class="row">
            <div class="col-md-6">
              <p><strong>Pay By:</strong> Credit Card</p>
            </div>
            <div class="col-md-6">
              <p><strong>Transaction ID:</strong> <?php echo e($order->stripe_transaction_id); ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          
        </div>
      </div>
    </div>
  </div>
  <div class="card m-4" style="width: 96%">
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <h5 class="card-title">Actions</h5>
          <div class="row">
            <div class="col-md-6">
              <label for="update_status">Update Order Status:</label>
              <select class="form-control" id="update_status" <?php if($order->cancel == 1): ?> disabled style="cursor: not-allowed;" <?php endif; ?>>
                  <option value="Order" <?php echo e($order->status == 'Order' ? 'selected' : ''); ?>>Order</option>
                  <option value="Shipped" <?php echo e($order->status == 'Shipped' ? 'selected' : ''); ?>>Shipped</option>
                  <option value="Out of delivery" <?php echo e($order->status == 'Out of delivery' ? 'selected' : ''); ?>>Out of delivery</option>
                  <option value="Delivered" <?php echo e($order->status == 'Delivered' ? 'selected' : ''); ?>>Delivered</option>
                  <option value="cancelled" <?php echo e($order->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
              </select>
            </div>
            <div class="col-md-6">
              <label for="update_status">&nbsp;</label>
              <button class="btn btn-danger w-100 mb-3 cancel-order" <?php if($order->cancel == 1): ?> disabled style="cursor: not-allowed;" <?php endif; ?>><?php if($order->cancel == 1): ?> Cancelled <?php else: ?> Cancel Order <?php endif; ?></button>
            </div>
          </div>
        </div>
        <div class="col-md-6">

        </div>
      </div>
    </div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script>
    $(document).ready(function() {
      previousValue = $('#update_status').val();
      $('#update_status').change(function() {
        
        var status = $(this).val();
        if(status == "cancelled"){
          if(confirm("Please confirm if you would like to proceed with canceling this order. Once the order is canceled, it cannot be retrieved.")){
        
            $.ajax({
              url: "<?php echo e(route('update_order_status')); ?>",
              method: "POST",
              data: {
                _token: "<?php echo e(csrf_token()); ?>",
                status: status,
                order_id: "<?php echo e($order->id); ?>"
              },
              success: function(data) {
                // console.log(data);
                location.reload();
              }
            });
          }else{
            $(this).val(previousValue);
          }
        }else{
          $.ajax({
            url: "<?php echo e(route('update_order_status')); ?>",
            method: "POST",
            data: {
              _token: "<?php echo e(csrf_token()); ?>",
              status: status,
              order_id: "<?php echo e($order->id); ?>"
            },
            success: function(data) {
              // console.log(data);
              location.reload();
            }
          });
        }
      });

      $('.cancel-order').on('click', function(){
        if(confirm('Please confirm if you would like to proceed with canceling this order. Once the order is canceled, it cannot be retrieved.')){
          $.ajax({
            url: "<?php echo e(route('cancel_user_order')); ?>",
            method: "POST",
            data: {
              _token: "<?php echo e(csrf_token()); ?>",
              order_id: "<?php echo e($order->id); ?>"
            },
            success: function(data) {
              // console.log(data);
              location.reload();
            }
          });
        }
      });
    });    
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admindefault', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/admin/single_order.blade.php ENDPATH**/ ?>