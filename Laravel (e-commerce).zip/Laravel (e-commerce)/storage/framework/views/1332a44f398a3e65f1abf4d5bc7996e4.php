

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<section class="product-section">
  <div class="container">
    <h2 class="section-title">Products</h2>
    <div class="product-grid">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product-item">
          <a href="<?php echo e(route('single_products', ['id' => $product->id])); ?>" class="product-image">
            <img src="<?php echo e(asset('products_image/'.$product->image)); ?>" alt="Product 1">
          </a>
          <div class="product-info">
            <h3 class="product-name"><?php echo e($product->name); ?></h3>
            <p class="product-price">$ <?php echo e($product->price); ?></p>
            <a href="<?php echo e(route('single_products', ['id' => $product->id])); ?>" class="product-button">More Details</a>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  <nav aria-label="Pagination">
    <ul class="pagination justify-content-center">
        <?php if($paginator->onFirstPage()): ?>
            <li class="page-item disabled">
                <span class="page-link"><?php echo e(__('Previous')); ?></span>
            </li>
        <?php else: ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev"><?php echo e(__('Previous')); ?></a>
            </li>
        <?php endif; ?>

        <?php for($i = 1; $i <= $paginator->lastPage(); $i++): ?>
            <?php if($i == $paginator->currentPage()): ?>
                <li class="page-item active"><span class="page-link"><?php echo e($i); ?></span></li>
            <?php else: ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($paginator->url($i)); ?>"><?php echo e($i); ?></a></li>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if($paginator->hasMorePages()): ?>
            <li class="page-item">
                <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"><?php echo e(__('Next')); ?></a>
            </li>
        <?php else: ?>
            <li class="page-item disabled">
                <span class="page-link"><?php echo e(__('Next')); ?></span>
            </li>
        <?php endif; ?>
    </ul>
  </nav>
</section>
<style>
    .product-section {
      padding: 50px 0;
      background-color: #f5f5f5;
    }
    .section-title {
      text-align: center;
      margin-bottom: 50px;
    }
    .product-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 20px;
    }
    .product-item {
      background-color: #fff;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s;
    }
    .product-item:hover {
      transform: translateY(-5px);
    }
    .product-image {
      display: block;
      width: 100%;
      height: 200px;
      overflow: hidden;
    }
    .product-image img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .product-info {
      padding: 20px;
    }
    .product-name {
      margin: 0 0 10px;
      font-size: 18px;
      font-weight: bold;
    }
    .product-price {
      margin: 0 0 10px;
      font-size: 16px;
      color: #333;
    }
    .product-button {
      display: block;
      width: 100%;
      padding: 10px;
      background-color: #f04;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      text-align: center;
    }
    .product-button:hover {
      background-color: #e03;
      text-decoration: none;
      color: white;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel (e-commerce)\resources\views/users/products.blade.php ENDPATH**/ ?>